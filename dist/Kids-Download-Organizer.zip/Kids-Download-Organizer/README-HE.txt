מתקין משפחתי: Python + Download Organizer

החבילה מכילה את כלי מיון ההורדות מתוך mac-toolkit.
אם חסר Python מתאים, המתקין יוריד אותו מהאתר הרשמי.

שלבים:
1. התחבר למשתמש של יונתן, יובל או יואב במק.
2. חלץ את ה-ZIP ופתח בלחיצה כפולה את Install Download Organizer.command.
3. אם קיים Python 3.9 ומעלה, המתקין ידלג על שלב Python.
4. אחרת הוא יוריד Python 3.15.2 מהאתר הרשמי, יאמת את הקובץ
   ויפתח את מתקין macOS. השלם את ההתקנה (דרושה סיסמת מנהל).
5. לאחר ההתקנה חזור לחלון Terminal המקורי ולחץ Return.
6. המתן להודעת SUCCESS. חזור על השלבים במשתמשי הילדים האחרים.

Python מותקן פעם אחת בכל המק. Download Organizer מותקן לכל משתמש בנפרד.
אין צורך ב-Git ואין צורך להקליד פקודות. נדרש אינטרנט אם Python חסר.
הורדות קיימות לא מוזזות, ורק הורדות חדשות ממוינות אוטומטית.
להסרה: פתח Uninstall Download Organizer.command (לא מסיר Python).

קוד המקור: https://github.com/a-spivaka/mac-toolkit/tree/main/download-organizer
